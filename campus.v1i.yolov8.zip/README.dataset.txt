# campus > 2024-06-02 10:45pm
https://universe.roboflow.com/bong-db2ea/campus-annep

Provided by a Roboflow user
License: CC BY 4.0

